create view cities as
select distinct `foo`.`persons`.`City` AS `City`
from `foo`.`persons`;

