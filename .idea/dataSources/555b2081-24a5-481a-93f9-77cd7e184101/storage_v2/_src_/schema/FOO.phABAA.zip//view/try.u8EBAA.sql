create view try as
select `foo`.`persons`.`Id_P`      AS `Id_P`,
       `foo`.`persons`.`LastName`  AS `LastName`,
       `foo`.`persons`.`FirstName` AS `FirstName`,
       `foo`.`persons`.`Address`   AS `Address`,
       `foo`.`persons`.`City`      AS `City`,
       `foo`.`persons`.`birthday`  AS `birthday`
from `foo`.`persons`
where (`foo`.`persons`.`City` <> 'TO');

